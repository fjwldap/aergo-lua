package io.blocko.aergo.sample;

import hera.api.model.ContractAddress;
import hera.api.model.ContractResult;
import hera.api.model.ContractTxReceipt;
import hera.api.model.Transaction;
import hera.api.model.TxHash;
import hera.client.AergoClient;
import hera.wallet.Wallet;

public class SampleMain {
	
	//테스트넷 접속 주소
	protected static String endpoint = "testnet.aergo.io:7845";
	
	
	//개인키
	protected static String encPrivateKey = "47jZxrNqT62LufXVADiEpqU3smFkPeoKv9diPTpDMBEEYB3WHB4DVNdaExoNWZwuMY9f1QJj3";

	//송신자 주소
	protected static String fromAddress = "AmM96n5JRx77iwktbVxiXD2eTrJYGRtZAWb5LM996GGDcmxmU9Hj";

	//패스워드 설정
	protected static String password = "password";
	
	//수신자 주소
	protected static String toAddress = "AmNzmdLAWBHCGVQUS4DFRxBqaf7PEEXJseiKJm5dhmdBokPyRv5u";
	
	//수수료 정책
	protected static String fee = "0";
	
	
	/* contract lua script
    function constructor(key, arg1, arg2)
      if key ~= nil then
        system.setItem(key, {intVal=arg1, stringVal=arg2})
      end
    end
     
    function set(key, arg1, arg2)
      system.setItem(key, {intVal=arg1, stringVal=arg2})
    end
     
    function get(key)
      return system.getItem(key)
    end
     
    abi.register(set, get)
   */
	//contract bytecode payload
	protected static String contractByteCode = "3boXDXfFKg67j8ZKcaYSBc7Bq6UikzWoEE68873y2syPry64FSY5yESWkJ4Qzzx5P8KH5afQiMeLtrWwegHkNVseYrPPLqCimh5nKswXN9x8jBpixqgmhzGF6RvYAw7zWz9ZqpBx4ocENdeKwCAjGaNbc3nSzSWBHV9ypdjcpGcAg4aRo2e3rcpBWtGPeLa4KXoxitTjpyUUcVozTLkDXaxBjXwt3kULiMETuiw6PSf92TueajDfb99GYK2vysz8JShT7MTBM8txnZP7ysAJsNwCxqjivAXkvw4b1DX66E4Uq8c28BCBkCv5vg7U2MKiGs9Xt6rp18X6mtv7Dr5sCxYgBpHL7EyRjaCHQHTm1tYQNt8JE4N7W3pVkhDRNLG9tM8W3Ry6aWYVp8SJf7atE1ppJ511BvUVQ1rLWbSAx8UcGJC9rSBqx2tHQuLdy395KZg1WbhNMwCtKRYUN21CPtiWSsFsq1ZYDNBwsMMxu7StJfqb29jZTZdD5rmokXkMdtpHs5RyKe9WMcDJx3pEByAtFNANrVuNDHG66UAYpPrcwKoRrLtyWZzQsxA9j94xETKGAiBTieipXRD24Kjx9dSCrfvnffouxiWKzv3edE3AAXzh5EXsU2nysRJTuALoZMKtLXQ8nzz9j3d68Yi96JH5xYumkc36XY2HFiiiZYVuTLmxFpoptwqiTQoC9z9b2ev3L8XM8tWWWC7647U8CEpWURXcsVjr7cfsdHbmyvuc6VS2uxEU5EGt";

	
	
	public static void main(String[] args) {
		
		run();
	}

	public static void run() {
		
		
		//1. Key생성(Account)
		//AergoCommon.createAergoKey();
		
		//2. 잔고 조회 
		//getBlances();
		
		//3.1 commitRawTransaction & Transaction, Block 조회 with wallet 
		commitRawTransaction();
		
		//3.2 sendTransaction  & Transaction, Block 조회 with wallet
		sendTransaction();
		
		//3.3 commitRawTransaction  & Transaction, Block 조회 with aergoclient
		//commitRawTransactionUseAergoClient();
		
		//4. aergoSmartContractRuns, deploy, execute, query 
		//aergoSmartContractRuns();
		
	}
	
	public static void aergoSmartContractRuns() {
		
		
		//client 생성 
		Wallet wallet = AergoCommon.getAergoWallet(endpoint);
	
		
		//Deploy
		ContractAddress contractAddress = AergoSmartContract.contractDeploy(wallet, password, encPrivateKey, contractByteCode);
		System.out.println(">>>>>>>>> contractId :: "+ contractAddress.getEncoded());
		
		//comfirm을 위해 대기
		try {
			Thread.sleep(4000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		String contractId = contractAddress.getEncoded();
		
		//실행
		
		String funcName = "set";
		String[] args1 = {"1", "Hello", "world"};
		ContractTxReceipt contractTxReceipt = AergoSmartContract.contractExecute(wallet, password, encPrivateKey, contractId,funcName, args1);

		
		//comfirm을 위해 대기
		try {
			Thread.sleep(4000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//조회용 contract 설정
		funcName = "get";
		String[] args2 = {"1"};
		
		//조회
		ContractResult contractResult = AergoSmartContract.contractQuery(wallet, contractId,funcName, args2);

	
		//client 종료
		wallet.close();
		
		
				
		
	}
	
	//잔고 조회 
	public static void getBlances() {
		
		AergoClient aergoClient = AergoCommon.getAergoClient(endpoint);
		
		AergoQuery.getBlance(aergoClient, fromAddress);
		
		aergoClient.close();
		
		
		Wallet wallet = AergoCommon.getAergoWallet(endpoint);
		
		AergoQuery.getBlance(wallet, fromAddress);
		
		//client 종료
		wallet.close();
	}
	
	
	//TX 전송 및 조회 used wallet.send
	public static void sendTransaction() {
		
		//client 생성 
		Wallet wallet = AergoCommon.getAergoWallet(endpoint);
		
		//전송 토큰  
		String amount = "1";
		
		//paylaod data
		String payload = "Aergo Sample Send Tx";
		
		
		TxHash txhash = AergoTransaction.sendTransaction(wallet, toAddress, password, encPrivateKey, payload, amount, fee);
		
		//comfirm을 위해 대기
		try {
			Thread.sleep(3000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//client 종료
		wallet.close();
		
		//AergoClient로 조회하기 
		AergoClient aergoClient = AergoCommon.getAergoClient(endpoint);
		
		//트랜잭션 조회
		Transaction transactionInfo = AergoQuery.getTransactionInfo(aergoClient, txhash.getEncoded());
		
		//블록 조회
		AergoQuery.getBlockInfo(aergoClient, transactionInfo.getBlockHash().toString());
		
		
		aergoClient.close();
		
	}
	
	
	//TX 전송 및 조회  used wallet.commit
	public static void commitRawTransaction() {
		
		
		Wallet wallet = AergoCommon.getAergoWallet(endpoint);
		
		String amount = "0";
		String payload = "Aergo Sample Commit Tx";
		
		//transaction 빌드 & commit
		TxHash txhash = AergoTransaction.buildCommitTransaction(wallet, toAddress, password, encPrivateKey, payload, amount, fee);
		
		
		//comfirm을 위해 대기
		try {
			Thread.sleep(3000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Transaction 조회 
		Transaction transactionInfo = AergoQuery.getTransactionInfo(wallet, txhash.getEncoded());
		
		//블록 조회
		AergoQuery.getBlockInfo(wallet, transactionInfo.getBlockHash().toString());
		
		//client 종료
		wallet.close();
		
		
	}
	
	//TX 전송 및 조회  used wallet.commit
	public static void commitRawTransactionUseAergoClient() {
		
		
		AergoClient aergoClient = AergoCommon.getAergoClient(endpoint);
		
		String amount = "0";
		String payload = "Aergo Sample Commit Tx";
		
		//transaction 빌드 & commit
		TxHash txhash = AergoTransaction.aergoClientBuildCommitTransaction(aergoClient, toAddress, password, encPrivateKey, payload, amount, fee);
		
		
		//comfirm을 위해 대기
		try {
			Thread.sleep(3000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Transaction 조회 
		Transaction transactionInfo = AergoQuery.getTransactionInfo(aergoClient, txhash.getEncoded());
		
		//블록 조회
		AergoQuery.getBlockInfo(aergoClient, transactionInfo.getBlockHash().toString());
		
		//client 종료
		aergoClient.close();
		
		
	}	

}




