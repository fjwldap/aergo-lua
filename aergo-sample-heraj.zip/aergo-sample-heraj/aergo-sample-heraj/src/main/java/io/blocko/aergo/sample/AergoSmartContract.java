package io.blocko.aergo.sample;

import hera.api.model.Authentication;
import hera.api.model.ContractAddress;
import hera.api.model.ContractDefinition;
import hera.api.model.ContractFunction;
import hera.api.model.ContractInterface;
import hera.api.model.ContractInvocation;
import hera.api.model.ContractResult;
import hera.api.model.ContractTxHash;
import hera.api.model.ContractTxReceipt;
import hera.api.model.Fee;
import hera.key.AergoKey;
import hera.wallet.Wallet;

public class AergoSmartContract {
	
	
	////SmartContract Deploy
	public static ContractAddress contractDeploy(Wallet wallet, String password, String encPrivateKey, String contractByteCode) {
	
		
		//수수료를 지불한 wallet설정 
		AergoKey adminKey = null;
		
		//키세팅 
		adminKey = AergoKey.of(encPrivateKey, password);
		
		//사용할 지갑을 저장
		wallet.saveKey(adminKey, password);
		
		//해당 지갑을 사용하기 위해 인증객체 생성 
		Authentication auth = Authentication.of(adminKey.getAddress(), password);

		//지갑 사용을 위해 unlock 
		wallet.unlock(auth); 
		
		//chainId 확인
		wallet.cacheChainIdHash();
		
		//contractbytecode 설정
		ContractDefinition definition = ContractDefinition.newBuilder()
		      .encodedContract(contractByteCode)
		      .build();
		
		
		//deploy 수행 
		ContractTxHash deployTxHash = wallet.deploy(definition, Fee.getDefaultFee());
		
		//deplo 수행결과 확인
		ContractTxReceipt receipt = wallet.getReceipt(deployTxHash);
		ContractInterface contractInterface = wallet.getContractInterface(receipt.getContractAddress());
		
		System.out.println(">>>>>>>>> deploy 트랙잭션 해시 정보 : " + deployTxHash);
		System.out.println(">>>>>>>>> contractInterface :: " + contractInterface);
		
		System.out.println(">>>>>>>>> 스마트컨트렉트 주소 :: " + receipt.getContractAddress());
			
	return receipt.getContractAddress();

	}
	
	//SmartContrac 실행
	public static ContractTxReceipt contractExecute(Wallet wallet, String password, String encPrivateKey, String contractId, String funcName, String[] args) {
		
		//수수료를 지불한 wallet설정 
		AergoKey adminKey = null;
		
		//키세팅 
		adminKey = AergoKey.of(encPrivateKey, password);
		
		//사용할 지갑을 저장
		wallet.saveKey(adminKey, password);
		
		//해당 지갑을 사용하기 위해 인증객체 생성 
		Authentication auth = Authentication.of(adminKey.getAddress(), password);

		//지갑 사용을 위해 unlock 
		wallet.unlock(auth); 
		
		//chainId 확인
		wallet.cacheChainIdHash();
		
		//contractId 설정 
		ContractAddress contractAddress = new ContractAddress(contractId);
		
		//사용할 contract interface 설정
		ContractInterface contractInterface = wallet.getContractInterface(contractAddress);
		
		//실행을 위한 builder 설정 
		ContractInvocation execution = contractInterface.newInvocationBuilder()
			   .function(funcName)
			   .args(args)
			   .build();
	    //contract 실행
	    ContractTxHash executeTxHash = wallet.execute(execution, Fee.getDefaultFee());
	    
	    try {
	    		Thread.sleep(1500L);
	    } catch (InterruptedException e) {
	    		e.printStackTrace();
	    }
	    
	    ContractTxReceipt receipt = wallet.getReceipt(executeTxHash);
	    
	    System.out.println(">>>>>>>>> execute 트랙잭션 해시 정보 : " + executeTxHash);
		
	    System.out.println(">>>>>>>>> 전송 상태 :: " + receipt.getStatus());
		System.out.println(">>>>>>>>> 전송 결과 :: " + receipt.getRet());
		
	   
		return receipt;
	}
	
	//SmartContract 조회
	public static ContractResult contractQuery(Wallet wallet, String contractId, String funcName, String[] args) {
		
		//contractIdt 설정 
		ContractAddress contractAddress = new ContractAddress(contractId);
		
		
		//사용할 contract interface 설정
		ContractInterface contractInterface = wallet.getContractInterface(contractAddress);
		
		//조회를 위한 builder 설정 
		ContractInvocation queryForConstructor = contractInterface.newInvocationBuilder()
			   .function(funcName)
			   .args(args)
			   .build();
	    
	    
	    //contract 조회
	    ContractResult result = wallet.query(queryForConstructor);
	    
	    System.out.println(">>>>>>>>> 조회 결과 :: " + result.toString());
	    
		return result;
	}

}
